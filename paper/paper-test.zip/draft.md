# Behavioral and Geometric Evaluation of Visual JEPA Representations


### ABSTRACT
We present a multi-axis behavioral and geometric evaluation of Visual Joint Embedding Predictive Architectures (JEPA), analyzing how learned visual representations respond to corruption, shortcut bias, temporal variation, ambiguity, dataset subsampling, and scaling. Across seven hypothesis-driven probes (H1–H7), we compare JEPA with ResNet-18, DINO-ViT, CLIP-ViT, and VideoMAE using representation-level metrics rather than downstream task accuracy.

Within our constrained experimental setting, JEPA exhibits slower semantic degradation under corruption, reduced reliance on background shortcuts, smoother robustness degradation profiles, stronger short-term temporal embedding stability, more structured responses to ambiguous inputs, improved preservation of local neighborhood structure under subsampling, and faster intrinsic dimensionality expansion under scale. Effect sizes and cross-hypothesis trends suggest these behavioral differences are consistent within our evaluation regime.

Rather than proposing a new architecture, this work contributes an exploratory behavioral evaluation framework and an empirical characterization of JEPA representation geometry, offering insight into how predictive learning objectives shape latent structure beyond standard benchmark-driven evaluation.

---

### 1. INTRODUCTION
Vision models are predominantly evaluated using accuracy-based benchmarks, which provide limited insight into the internal organization, stability, and geometry of learned representations. Predictive and self-supervised learning frameworks, including JEPA, claim to produce more semantically structured and stable latent representations; however, systematic behavioral evaluations of these claims remain limited.

In this work, we evaluate JEPA from a representation-centric perspective, focusing on how embeddings behave under controlled perturbations rather than how models perform on classification tasks. We probe seven representational properties: semantic faithfulness, shortcut bias, robustness geometry, temporal stability, ambiguity handling, dataset subsampling stability, and scaling behavior.

**Contributions** :

- We introduce a seven-axis behavioral probe suite for exploratory evaluation of visual representation structure.

- We provide an early multi-probe behavioral analysis of JEPA relative to CNN and contrastive baselines.

- We present empirical evidence that predictive representations in JEPA exhibit smoother degradation profiles, stronger object-centric encoding, more structured ambiguity responses, and accelerated intrinsic dimensionality expansion under scale.

Our goal is not to claim task-level superiority, but to characterize how JEPA organizes semantic information in latent space under controlled experimental conditions.

---

### 2. RELATED WORK 
Our study builds on prior work in self-supervised and predictive representation learning, including contrastive methods such as SimCLR, DINO, and CLIP, as well as JEPA-style predictive architectures. Related research has explored robustness, shortcut learning, texture bias, and representation geometry in vision models, though most evaluations emphasize downstream accuracy or isolated failure modes.

Recent efforts in representation analysis investigate embedding smoothness, manifold structure, corruption robustness, and interpretability. However, few studies provide multi-axis behavioral diagnostics spanning semantic, temporal, ambiguous, and scaling regimes. Our work complements this literature by offering an exploratory behavioral evaluation framework focused on representation dynamics rather than task performance.

---

### 3. METHODOLOGY : H1 - H7 Probes

We design seven hypothesis-driven behavioral probes (H1–H7) to evaluate representation stability and structure. All experiments operate on frozen pretrained encoders, isolating representational properties rather than training dynamics.

**Models :**

We evaluate JEPA against ResNet-18, DINO-ViT, CLIP-ViT, and VideoMAE.

**Datasets :**

We construct a controlled exploratory evaluation dataset consisting of **384** images retrieved via the **Pexels API**. Images are distributed across eight semantic categories: **abstract (29), ambiguous (40), animals (65), humans (70), indoor scenes (45), outdoor scenes (45), objects (45), and vehicles (45).** 

This dataset is intended for behavioral probing rather than **large-scale generalization** and allows **controlled analysis of representation dynamics** under varied semantic conditions.

For temporal analysis, we use **two short video clips (~11 seconds each)**, evaluated across multiple vision encoders including VideoMAE.
 
Due to limited sample size, video-based findings are treated as **illustrative rather than statistically conclusive.**

---

### Compute and Experimental Constraints

All experiments were conducted on a single NVIDIA **RTX 3050 GPU (6GB VRAM) with 16GB system RAM**. Due to memory constraints, compact model variants were evaluated rather than the largest available **JEPA, CLIP, DINO, or ResNet checkpoints.**

Findings should therefore be interpreted as **empirical observations under constrained compute and model scale, rather than definitive large-scale comparisons.**

---

**H1 — Semantic Faithfulness under Corruption**

We measure representation similarity decay under **blur and Gaussian noise using similarity decay slopes, corruption curve stability, and Cohen’s d**. 

Lower degradation slopes indicate stronger semantic preservation.

---
**H2 — Shortcut Bias (Foreground vs Background)**

Foreground and background regions are **perturbed independently to compute similarity differentials, a Shortcut Dependency Index (SDI), and effect sizes.** 

Higher SDI indicates stronger object-centric encoding.

---
**H3 — Robustness Geometry across Corruption Types**

We evaluate multiple corruption regimes using **degradation slopes, failure curvature, and area under robustness curves (AURC).** 

Lower curvature indicates smoother degradation profiles.

---
**H4 — Temporal Stability across Video Frames**

We compute **mean temporal embedding similarity, Temporal Stability Score (TSS), and drift variance across frame sequences.**

Findings are interpreted as **illustrative due to limited video samples.**

---
**H5 — Ambiguity Handling**

Under ambiguous visual stimuli, we measure **embedding spread, cluster silhouette, and bifurcation strength.** 

Higher values indicate more structured multi-modal representation behavior.

---
**H6 — Stability under Dataset Subsampling**

We evaluate **k-NN neighborhood overlap, embedding drift, collapse scores, and embedding variance** under progressive subsampling. 

This probe measures local structural robustness, not universal data efficiency.

---
**H7 — Scaling Geometry**

We estimate **intrinsic dimensionality, cluster compactness, margin growth, and neighborhood stability.**

Faster intrinsic dimensionality expansion suggests richer latent capacity under increasing scale.

---

### 4. RESULTS 

### H1 - Semantic Stability

JEPA exhibits slower similarity decay within our evaluation setting under corruption than ResNet, DINO, and CLIP, indicating stronger preservation of semantic identity

---

### H2 - Shortcut Bias

JEPA demonstrates reduced reliance on background texture, with higher object-centric dependency scores relative to baselines

---

### H3 - Robustness Geometry

JEPA displays smoother degradation profiles under corruption, whereas baseline models show sharper representational collapse

---

### H4 — Temporal Stability

Across two evaluated video clips, JEPA achieves higher temporal stability scores and lower drift variance than ResNet, DINO, CLIP, and VideoMAE, suggesting stronger short-term identity consistency under constrained temporal evaluation.

---

### H5 - Ambiguity Handling

Under ambiguous conditions, JEPA maintains broader embedding spread, stronger cluster separation, and increased bifurcation dynamics, indicating preservation of competing semantic interpretations

---
### H6 — Data Subsampling

JEPA preserves local neighborhood structure more consistently than baselines, reflected in higher k-NN overlap. 

Other stability metrics exhibit mixed behavior, indicating that JEPA’s advantage is concentrated in local structural robustness rather than universal data efficiency.

---

### H7 - Scaling Geometry 

JEPA demonstrates faster intrinsic dimensionality expansion under scale, consistent with richer latent capacity growth relative to contrastive and CNN baselines

---

### 5. DISCUSSION

Across seven exploratory behavioral probes, JEPA exhibits stronger semantic stability, reduced shortcut reliance, smoother robustness degradation, and more structured responses to ambiguity compared to CNN and contrastive baselines. These patterns align with the hypothesis that predictive learning objectives encourage smoother and more semantically organized latent representations.

However, JEPA does not uniformly outperform baselines across all metrics. In particular, performance under dataset subsampling is mixed, suggesting that representational smoothness does not necessarily imply universal sample efficiency.

Rather than claiming universal superiority, we interpret JEPA’s advantage as structural: it appears to encode semantic information in a more geometry-preserving and object-centric manner under corruption, ambiguity, and scaling regimes. These findings contribute empirical evidence toward understanding how predictive representation learning shapes latent manifold structure beyond accuracy-centric evaluation.

---

### 6. LIMITATIONS 

This study evaluates pretrained models on a small, custom exploratory dataset and limited video samples under constrained compute. As a result, findings should not be interpreted as universal model rankings or large-scale generalization claims.

Larger datasets, broader model variants, and downstream task evaluations may yield different quantitative outcomes.Our composite scoring framework reflects exploratory aggregation rather than a universal ranking metric.

---

### 7. CONCLUSION 

We introduce a multi-axis behavioral evaluation framework and apply it to Visual JEPA representations. Within our constrained experimental setting, JEPA exhibits stronger semantic preservation under corruption, reduced shortcut reliance, smoother degradation behavior, improved temporal stability, structured ambiguity handling, and accelerated intrinsic dimensionality expansion, while showing mixed behavior under dataset subsampling.

These results provide exploratory evidence that predictive learning objectives shape latent representation geometry in ways that emphasize semantic stability and structural coherence. Future work should extend this analysis to larger model scales, broader datasets, and downstream task settings.

---